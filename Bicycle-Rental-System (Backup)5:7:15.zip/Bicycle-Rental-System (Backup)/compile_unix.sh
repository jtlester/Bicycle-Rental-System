javac ./*.java ./model/*.java ./userinterface/*.java 
javac -d classes -cp classes:. model/*.java userinterface/*.java